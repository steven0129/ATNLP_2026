'''
Question 3
Create a variable `INSTRUCTION` and fill in the prompt with instructions provided in the file `prompt-instruction.txt.`
'''
raise NotImplementedError("Create a variable `INSTRUCTION` and fill in the prompt with instructions provided in the file `prompt-instruction.txt.`")   