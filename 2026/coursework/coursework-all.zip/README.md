# ATNLP Coursework

See README.md files in each directory, partI/ and partII/, and coursework main PDF under coursework.pdf.

Gradescope form to submit answers will only be open when the assignment is officially released.

The file coursework-all.zip consists of all relevant content. You can download it to solve the assignment locally.
